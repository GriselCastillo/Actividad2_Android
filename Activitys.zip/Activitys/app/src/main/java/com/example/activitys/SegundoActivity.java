package com.example.activitys;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

public class SegundoActivity extends AppCompatActivity {

    private TextView tv1;
    private TextView tv2;
    private TextView tv3;
    private TextView tv4;
    private TextView tv5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segundo);

        tv1 = (TextView) findViewById(R.id.tv1);
        tv2 = (TextView) findViewById(R.id.tv2);
        tv3 = (TextView) findViewById(R.id.tv3);
        tv4 = (TextView) findViewById(R.id.tv4);
        tv5 = (TextView) findViewById(R.id.tv5);

        String dato1 = getIntent().getStringExtra("dato1");
        tv1.setText("Nombre:" + dato1);

        String dato2 = getIntent().getStringExtra("dato2");
        tv2.setText("Apellido:" + dato2);

        String dato3 = getIntent().getStringExtra("dato3");
        tv3.setText("Correo Electronico:" + dato3);

        String dato4 = getIntent().getStringExtra("dato4");
        tv4.setText("Detalle Contacto:" + dato4);

        String dato5 = getIntent().getStringExtra("dato5");
        tv5.setText("Fecha de Nacimiento:" + dato5);
    }

    //Metodo Regresar
    public void Regresar(View view) {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
    //Metodo para Editar

}
